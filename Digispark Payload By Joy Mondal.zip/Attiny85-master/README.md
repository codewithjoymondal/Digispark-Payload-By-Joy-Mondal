<p align="center">
<img src="https://i.ibb.co/jZ2wvX0/NEWEV-AT.png" width="172" height="123">
</p>

# DigiSpark Attiny85 poor man's RubberDucky
For people who can't buy or are too cheap to buy RubberDucky, DigiSpark Attiny85 is the solution to their problems. Because it's possible to use it as HID thanks to "DigiKeyboard.h" it can be use as keyboard to send keystrokes to computer which can be use for pranking your people to creating a backdoor in target system.

## What's here?
I have created this repo for sharing my payloads for DigiSpark Attiny85. It's my first time programming any device and so far no fires. All the payloads are tested on Attiny85 and created on Arduino IDE.

## Getting Started
For people like me who are new to this i would suggest visiting [Maker.pro](https://maker.pro/arduino/projects/how-to-build-a-rubber-ducky-usb-with-arduino-using-a-digispark-module) for instruction on setting up development environment for Attiny85.

## Payloads
Following is the list of payloads i have worked on so far

>Wi-Fi password stealer: Grabs Windows saved Wi-Fi passwords and send them to your remote web server

>Windows Crasher: Various payloads for crashing windows

>UAC Bypass: Different methods to bypass windows UAC

>BackDoor: Creates backdoor for later access

>KeyLogger: For logging and sending typed keys

>Windows Phisher: Phisher for windows credentials

>Sam Dumper: Dump windows password files (SAM) and send them to remote location

>Payload Dropper: Download and exeute files from internet

## DISCLAIMER
All the software/scripts/applications/things in this repository are provided as is, without warranty of any kind. Use of these software/scripts/applications/things is entirely at your own risk. Creator of these softwares/scripts/applications/things is not responsible for any direct or indirect damage to your own or defiantly someone else's property resulting from the use of these software/scripts/applications/things.
